import pandas as pd
import numpy as np
import joblib

# Load trained model
model = joblib.load(r'C:\my desktop\SEPSIS PROJECT\model\xgboost_sepsis_model.pkl')

# Example new patient data as a dictionary (same features as training)
test_patient_critical = {
    'HR': 130,
    'O2Sat': 85,
    'Temp': 39.5,
    'SBP': 80,
    'MAP': 55,
    'DBP': 40,
    'Resp': 30,
    'EtCO2': 18,
    'BaseExcess': -10,
    'HCO3': 15,
    'FiO2': 0.8,
    'pH': 7.1,
    'PaCO2': 60,
    'SaO2': 80,
    'AST': 250,
    'BUN': 45,
    'Alkalinephos': 200,
    'Calcium': 7.5,
    'Chloride': 90,
    'Creatinine': 3.5,
    'Bilirubin_direct': 2.5,
    'Glucose': 200,
    'Lactate': 5.5,
    'Magnesium': 1.4,
    'Phosphate': 5.5,
    'Potassium': 5.8,
    'Bilirubin_total': 5.0,
    'TroponinI': 0.9,
    'Hct': 25,
    'Hgb': 9,
    'PTT': 80,
    'WBC': 25,
    'Fibrinogen': 500,
    'Platelets': 80,
    'Age': 72,
    'Gender': 1,
    'Unit1': 1,
    'Unit2': 0,
    'HospAdmTime': -150,
    'ICULOS': 24
}


# Convert to DataFrame
input_df = pd.DataFrame([test_patient_critical])

# Select only numeric columns and fill any missing values (if any)
input_df = input_df.select_dtypes(include=['number']).fillna(input_df.mean())

# Predict
prediction = model.predict(input_df)

# Output result
if prediction[0] == 1:
    print("🚨 Sepsis likely - immediate attention needed.")
else:
    print("✅ No signs of sepsis detected.")
