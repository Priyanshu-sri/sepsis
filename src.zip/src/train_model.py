from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.metrics import classification_report, confusion_matrix
import numpy as np

def train_model(df):
    # Split data into features (X) and target (y)
    X = df.drop(['SepsisLabel', 'source_file'], axis=1)  # Drop target column 'SepsisLabel' and 'source_file'
    y = df['SepsisLabel']  # Target variable (Sepsis or not)

    # Split into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize Random Forest Classifier with class weights balanced
    model = RandomForestClassifier(class_weight='balanced', random_state=42)

    # Define hyperparameters for GridSearch
    param_grid = {
        'n_estimators': [50, 100, 200],
        'max_depth': [10, 20, 30, None],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4]
    }

    # Set up GridSearchCV to search for the best parameters
    grid_search = GridSearchCV(estimator=model, param_grid=param_grid, cv=3, n_jobs=-1, verbose=2)

    # Fit the model with GridSearch
    grid_search.fit(X_train, y_train)

    # Get the best model from GridSearch
    best_model = grid_search.best_estimator_

    # Predict on the test set
    y_pred = best_model.predict(X_test)

    # Print classification report
    print("Best Parameters from GridSearchCV:", grid_search.best_params_)
    print(classification_report(y_test, y_pred))

    # Adjust threshold for better recall (optional)
    best_threshold = adjust_threshold(best_model, X_test, y_test)

    # Return the trained best model and data splits
    return best_model, X_train, y_train, X_test, y_test

def adjust_threshold(model, X_test, y_test):
    # Get the predicted probabilities for the test set
    y_prob = model.predict_proba(X_test)[:, 1]

    # Test different thresholds to optimize recall
    thresholds = np.arange(0.0, 1.0, 0.05)
    best_threshold = 0.5
    best_recall = 0.0

    for threshold in thresholds:
        y_pred_adjusted = (y_prob >= threshold).astype(int)
        cm = confusion_matrix(y_test, y_pred_adjusted)
        recall = cm[1, 1] / (cm[1, 1] + cm[1, 0])  # Recall = TP / (TP + FN)

        if recall > best_recall:
            best_recall = recall
            best_threshold = threshold

    print(f"Best Threshold: {best_threshold}, Best Recall: {best_recall}")
    return best_threshold

def cross_validate_model(model, X, y):
    # Define the cross-validation method
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    for fold, (train_idx, val_idx) in enumerate(skf.split(X, y)):
        X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
        y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]

        # Train the model
        model.fit(X_train, y_train)

        # Predict and evaluate
        y_pred = model.predict(X_val)
        print(f"Fold {fold+1}")
        print(classification_report(y_val, y_pred))
