from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score

# Assuming you have already loaded your data into X_train, X_test, y_train, y_test

# Initialize the Random Forest Classifier
rf = RandomForestClassifier(random_state=42)

# Define the parameter grid for hyperparameter tuning with fewer values
param_grid = {
    'n_estimators': [50, 100],  # Reduce the number of estimators
    'max_depth': [10, 20],       # Reduce the range of depths
    'min_samples_split': [2, 5], # Reduce the number of splits
    'min_samples_leaf': [1, 2],  # Reduce the leaf size
}

# Perform GridSearchCV with fewer combinations (using 3-fold cross-validation)
grid_search = GridSearchCV(estimator=rf, param_grid=param_grid, cv=3, n_jobs=-1, verbose=2)

# Fit the model
grid_search.fit(X_train, y_train)

# Print the best hyperparameters found by the grid search
print(f"Best hyperparameters: {grid_search.best_params_}")

# Make predictions using the best model
y_pred = grid_search.best_estimator_.predict(X_test)

# Evaluate the model's accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.4f}")
