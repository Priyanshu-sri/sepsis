# save_model.py
import joblib

def save_model(model):
    joblib.dump(model, 'sepsis_detection_model.pkl')
