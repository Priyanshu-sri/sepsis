from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import joblib
import shap
import os

app = Flask(__name__)
model = joblib.load('model/xgboost_sepsis_model.pkl')

# Load SHAP explainer
explainer = shap.TreeExplainer(model)

CSV_FILE = 'patient_data.csv'

@app.route('/', methods=['GET', 'POST'])
def home():
    prediction = None
    confidence = None
    label = None
    selected_patient = None
    form_data = {}
    shap_values_display = []

    if request.method == 'POST':
        form_data = request.form.to_dict()
        selected_patient = form_data.get("Name")

        # Fill missing values with defaults (mean or neutral)
        features = [
            'HR','O2Sat','Temp','SBP','MAP','DBP','Resp','EtCO2','BaseExcess','HCO3','FiO2',
            'pH','PaCO2','SaO2','AST','BUN','Alkalinephos','Calcium','Chloride','Creatinine',
            'Bilirubin_direct','Glucose','Lactate','Magnesium','Phosphate','Potassium',
            'Bilirubin_total','TroponinI','Hct','Hgb','PTT','WBC','Fibrinogen','Platelets',
            'Age','Gender','Unit1','Unit2','HospAdmTime','ICULOS'
        ]
        input_data = [float(form_data.get(f, 0)) for f in features]

        # Predict the probability of sepsis
        prediction_prob = model.predict_proba([input_data])[0][1]
        prediction = int(prediction_prob > 0.5)
        confidence = round(prediction_prob * 100, 2)

        if confidence >= 90:
            label = "Most likely"
        elif confidence >= 70:
            label = "Likely"
        elif confidence >= 50:
            label = "Possibly"
        else:
            label = "Unlikely"

        # Convert prediction to a human-readable status
        prediction_status = "Sepsis" if prediction == 1 else "No Sepsis"

        # Get SHAP values for feature importance
        shap_values = explainer.shap_values([input_data])

        # Check if shap_values is a single value or an array
        if isinstance(shap_values, list):  # For multi-class classification
            shap_values = shap_values[1]  # Get SHAP values for the positive class (sepsis)

        # Prepare data to display in a human-readable format
        feature_names = [
            'Heart Rate', 'Oxygen Saturation', 'Temperature', 'Systolic BP', 'MAP', 'Diastolic BP', 
            'Respiratory Rate', 'EtCO2', 'Base Excess', 'HCO3', 'FiO2', 'pH', 'PaCO2', 'SaO2', 
            'AST', 'BUN', 'Alkaline Phosphatase', 'Calcium', 'Chloride', 'Creatinine', 'Direct Bilirubin',
            'Glucose', 'Lactate', 'Magnesium', 'Phosphate', 'Potassium', 'Total Bilirubin', 'Troponin I',
            'Hematocrit', 'Hemoglobin', 'PTT', 'WBC', 'Fibrinogen', 'Platelets', 'Age', 'Gender', 
            'Unit1', 'Unit2', 'Hospital Admission Time', 'ICU Length of Stay'
        ]

        shap_values_display = []
        for i, value in enumerate(shap_values[0]):  # Now shap_values is a list we can iterate
            if abs(value) > 0.05:  # Filter to show only important features
                shap_values_display.append({
                    'Feature': feature_names[i],
                    'Impact': "Increases" if value > 0 else "Decreases",
                    'Value': form_data.get(features[i], 0),
                    'SHAP Value': round(value, 2)
                })

        # Save or update patient data
        row = {f: form_data.get(f, '') for f in ['Name'] + features}
        new_df = pd.DataFrame([row])

        if os.path.exists(CSV_FILE):
            df = pd.read_csv(CSV_FILE)
            df = df[df['Name'] != form_data['Name']]  # Remove previous record for the patient
            df = pd.concat([df, new_df], ignore_index=True)
        else:
            df = new_df

        df.to_csv(CSV_FILE, index=False)

        return render_template("result.html", prediction=prediction_status, confidence=confidence, label=label, shap_values=shap_values_display)

    # For dropdown list
    names = []
    if os.path.exists(CSV_FILE):
        df = pd.read_csv(CSV_FILE)
        names = df['Name'].dropna().unique().tolist()
        if 'selected' in request.args:
            selected_name = request.args['selected']
            form_data = df[df['Name'] == selected_name].iloc[0].to_dict()

    return render_template("index.html", prediction=prediction, form_data=form_data, names=names)

if __name__ == '__main__':
    app.run(debug=True)
