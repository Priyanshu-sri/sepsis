import pandas as pd
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from xgboost import XGBClassifier
from sklearn.metrics import classification_report

# Load the dataset
df = pd.read_excel(r'C:\my desktop\SEPSIS PROJECT\data\dataset_for_sepsis_detection.xlsx')

# Drop columns that are not useful or non-numeric
df = df.drop(columns=['source_file'], errors='ignore')  # remove if it exists

# Separate features and target
X = df.drop(columns=['SepsisLabel'])
y = df['SepsisLabel']

# Keep only numeric columns in X (SMOTE needs numeric data)
X = X.select_dtypes(include=['number'])

# Fill missing values with column mean
X = X.fillna(X.mean())

# Apply SMOTE to handle class imbalance
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X, y)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X_resampled, y_resampled, test_size=0.2, random_state=42)

# Initialize and train XGBoost model
model = XGBClassifier(use_label_encoder=False, eval_metric='logloss')
model.fit(X_train, y_train)

# Predict on test set
y_pred = model.predict(X_test)

# Print classification report
print(classification_report(y_test, y_pred))
