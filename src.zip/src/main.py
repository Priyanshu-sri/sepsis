import pandas as pd
from train_model import train_model
from evaluate_model import evaluate_model

# Load your dataset
df = pd.read_excel('data\dataset_for_sepsis_detection.xlsx')



# Train the model
model, X_train, y_train, X_test, y_test = train_model(df)

# Evaluate the model
evaluate_model(model, X_test, y_test)
