import pandas as pd

def preprocess_data(filepath):
    df = pd.read_excel(filepath)
    
    # Drop non-numeric columns (like 'source_file')
    df = df.select_dtypes(include=['number'])
    
    # Replace NaNs with column median
    df.fillna(df.median(numeric_only=True), inplace=True)

    # Ensure SepsisLabel is binary (0 or 1)
    df['SepsisLabel'] = df['SepsisLabel'].apply(lambda x: 1 if x >= 1 else 0)

    return df
